public class Main {
    public static void main(String[] args) {
        for(double y=-1;y<=7;y++){
            for(double x=0;x<=24;x++){
                if(y==x/3-1||x==12||y==3)
                    System.out.print("*");
                else
                    System.out.print(" ");
            }
            System.out.print("\n");
        }
    }
}

