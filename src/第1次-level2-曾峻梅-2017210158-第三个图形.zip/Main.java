public class Main {
    public static void main(String[] args) {
        for(double y=-10;y<=10;y+=1){
            for(double x=-16;x<=16;x+=0.5){
                if(y*y-4*x-1<=0.01&&y*y-4*x>=0||x==0||y==0)
                    System.out.print("*");
                else
                    System.out.print(" ");
            }
            System.out.print("\n");
        }
    }
}


