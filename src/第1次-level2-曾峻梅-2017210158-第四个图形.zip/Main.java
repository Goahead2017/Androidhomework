public class Main {
    public static void main(String[] args) {
        for(double y=-6;y<=6;y+=0.8){
            for(double x=-6;x<=6;x+=0.35){
                if(x*x+y*y-16<=0.05&&x*x+y*y-12>=0.05||x==0.29999999999999893 ||y==0.39999999999999925)
                    System.out.print("*");
                else
                    System.out.print(" ");
            }
            System.out.print("\n");
        }
    }
}





