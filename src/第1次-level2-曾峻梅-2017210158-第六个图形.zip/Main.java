public class Main {
    public static void main(String[] args) {
        for(double y=2;y>=-2;y-=0.1){
            for(double x=-2;x<=2;x+=0.03){
                if(x*x+Math.pow((y-Math.pow(x*x,1.0/3)),2)<=1||x==0.010000000000001535||y==0.09999999999999937)
                    System.out.print("*");
                else
                    System.out.print(" ");
            }
            System.out.print("\n");
        }
    }
}





