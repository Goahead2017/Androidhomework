public class Main {
    public static void main(String[] args) {
        for(double y=-10;y<=10;y+=1){
            for(double x=-6;x<=6;x+=0.5){
                if(y+x*x<=0.8&&y+x*x>=-1||x==0||y==-1)
                    System.out.print("*");
                else
                    System.out.print(" ");
            }
            System.out.print("\n");
        }
    }
}

