import java.util.Random;

class Putong {
    final int number1 = 5;
    static final int money1 = 1;
    final int totalMoney1 = 5;

    public int getNumber1() {
        return number1;
    }

    public int getMoney1() {
        return money1;
    }

    public int getTotalMoney1() {
        return totalMoney1;
    }

    public static void hongBao1() {
        String name[] = {"甲", "乙", "丙", "丁", "戊"};
        Random random = new Random();
        int a = -1;
        for (int i = 0; i < 5; i++) {
            int j = random.nextInt(5);
            if (a != j) {
                System.out.println("红包金额:" + money1 + "\t" + "抢夺人：" + name[j]);
            } else {
                a = j;
                i--;
            }
        }
    }
}

    public class Main {
        public static void main(String[] args) {
            System.out.println("甲、乙、丙、丁、戊五人开始抢普通红包");
            Putong po = null;
            po = new Putong();
            System.out.println("红包个数：" + po.getNumber1() + "\t" + "总金额：" + po.getTotalMoney1() + "\t" + "红包金额：" + po.getMoney1());
            Putong.hongBao1();
            System.out.println("甲、乙、丙、丁、戊五人开始抢运气红包");
            Yunqi yun = null;
            yun = new Yunqi();
            System.out.println("红包个数："+yun.getNumber2()+"\t"+"总金额："+yun.getTotalMoney2()+"\t");
            Yunqi.hongBao2();
        }
    }
class Yunqi {
    final int number2 = 5;
    static final int totalMoney2 = 16;

    public int getNumber2() {
        return number2;
    }

    public int getTotalMoney2() {
        return totalMoney2;
    }

    public static void hongBao2()

    {
        int qian[] = {1, 2, 3, 4, 5};
        String name2[] = {"甲", "乙", "丙", "丁", "戊"};
        int sum = 0;
        Random random = new Random();
        for (int i = 0; i < qian.length - 1; i++) {
            int j = random.nextInt(3);
            System.out.print("红包金额：" + qian[j] + "\t");
            sum += qian[j];
        }
        qian[4] = 16 - sum;
        System.out.print("红包金额：" + qian[4]);
        System.out.print("\n");
        for (int i = 0; i < name2.length; i++) {
            int j = random.nextInt(5);
            System.out.print("抢夺人:" + name2[j] + "\t\t");
        }
    }
}