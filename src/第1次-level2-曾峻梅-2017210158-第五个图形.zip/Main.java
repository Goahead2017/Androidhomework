public class Main {
    public static void main(String[] args) {
        for(double y=-8;y<=8;y+=1){
            for(double x=-6;x<=6;x+=0.4){
                if(Math.abs(y+x*x*x-0.01)<=0.8||x==7.771561172376096E-16||y==0)
                    System.out.print("*");
                else
                    System.out.print(" ");
            }
            System.out.print("\n");
        }
    }
}





